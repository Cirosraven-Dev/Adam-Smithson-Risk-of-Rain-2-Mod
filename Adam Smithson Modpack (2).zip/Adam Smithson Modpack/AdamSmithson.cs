using RoR2;
using UnityEngine;
using R2API;
using System.Collections;

public class AdamSmithson : SurvivorBase
{
    public override void Initialize()
    {
        base.Initialize();
        CreateCharacter();
        RegisterSkills();
        ApplyPassives();
    }

    private void CreateCharacter()
    {
        CharacterBody body = gameObject.GetComponent<CharacterBody>();
        body.baseMaxHealth = 10000f;
        body.baseDamage = 12f;
        body.baseMoveSpeed = 7f;
        body.autoCalculateLevelStats = true;
    }

    private void RegisterSkills()
    {
        SkillLocator skillLocator = gameObject.GetComponent<SkillLocator>();
        
        skillLocator.primary = CreateSkill("Bloody Knuckles", 
            "Melee punch dealing 500% damage, heals for 2% missing HP.", "skill_primary.png");
        
        skillLocator.secondary = CreateSkill("Noir Pistol", 
            "Fires 12 shots, 1000% damage each, 10s cooldown, slows enemies by 5%.", "skill_secondary.png");
        
        skillLocator.utility = CreateSkill("Parasitic Bloom", 
            "Places a healing plant that grants 20% HP per kill. One plant at a time.", "skill_utility.png");
        
        skillLocator.special = CreateSkill("Antique Telephone", 
            "Gain 10x health and damage for 1 minute, then suffer a 25% slow debuff for 10s.", 
            "skill_special.png", 60f);
    }

    private GenericSkill CreateSkill(string name, string description, string iconPath, float cooldown = 0f)
    {
        SkillDef skillDef = ScriptableObject.CreateInstance<SkillDef>();
        skillDef.skillName = name;
        skillDef.skillDescription = description;
        skillDef.icon = AdamSmithsonAssets.LoadSkillIcon(iconPath);
        skillDef.baseRechargeInterval = cooldown;
        return new GenericSkill { skillDef = skillDef };
    }

    private void ApplyPassives()
    {
        CharacterBody body = gameObject.GetComponent<CharacterBody>();

        body.onCharacterUpdate += () =>
        {
            bool inDarkness = CheckDarkness(body.transform.position);
            if (inDarkness)
            {
                body.moveSpeed *= 1.15f;
                body.AddTimedBuff(RoR2Content.Buffs.CritGlasses, 2f);
            }
        };
    }

    private bool CheckDarkness(Vector3 position)
    {
        // Placeholder logic for detecting darkness
        return Physics.Raycast(position, Vector3.down, 10f, LayerMask.GetMask("Darkness"));
    }
}
using UnityEngine;
using System.IO;

public static class AdamSmithsonAssets
{
    private static string assetPath = "RiskOfRain2/mods/AdamSmithsonMod/assets/icons/skills/";

    public static Sprite LoadSkillIcon(string fileName)
    {
        string fullPath = Path.Combine(assetPath, fileName);
        
        if (File.Exists(fullPath))
        {
            byte[] imageData = File.ReadAllBytes(fullPath);
            Texture2D texture = new Texture2D(2, 2);
            texture.LoadImage(imageData);
            return Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f));
        }

        Debug.LogError($"[AdamSmithsonMod] Skill icon not found: {fullPath}");
        return null;
    }
}
using BepInEx;
using RoR2;
using UnityEngine;

[BepInPlugin("com.yourname.adamsmithson", "Adam Smithson Mod", "1.0.0")]
public class AdamSmithsonPlugin : BaseUnityPlugin
{
    public static GameObject characterPrefab;

    public void Awake()
    {
        CreateCharacter();
        RegisterSurvivor();
    }

    private void CreateCharacter()
    {
        characterPrefab = PrefabAPI.InstantiateClone(Resources.Load<GameObject>("Prefabs/CharacterBodies/CommandoBody"), "AdamSmithsonBody", true);
        // Modify stats, abilities, etc.
    }

    private void RegisterSurvivor()
    {
        SurvivorDef survivorDef = ScriptableObject.CreateInstance<SurvivorDef>();
        survivorDef.bodyPrefab = characterPrefab;
        survivorDef.displayPrefab = characterPrefab; // Optional, needed for character selection screen
        survivorDef.primaryColor = Color.red;
        survivorDef.cachedName = "Adam Smithson";

        ContentAddition.AddSurvivorDef(survivorDef);
    }
}
SurvivorCatalog.allSurvivorDefs.Add(survivorDef);
characterPrefab.SetActive(true);
Resources.Load<GameObject>("Prefabs/CharacterBodies/CommandoBody")
Resources.Load<GameObject>("Prefabs/CharacterBodies/ToolbotBody") // MUL-T
using RoR2;
using UnityEngine;

public class AdamSmithsonCharacter
{
    public static void RegisterCharacter()
    {
        GameObject adamPrefab = PrefabAPI.InstantiateClone(Resources.Load<GameObject>("Prefabs/CharacterBodies/CommandoBody"), "AdamSmithsonBody", true);
        
        // Load the PNG images
        string modPath = Path.Combine(BepInEx.Paths.PluginPath, "AdamSmithson");
        Texture2D portrait = ImageLoader.LoadTexture(Path.Combine(modPath, "portrait.png"));

        SurvivorDef adamSurvivor = ScriptableObject.CreateInstance<SurvivorDef>();
        adamSurvivor.bodyPrefab = adamPrefab;
        adamSurvivor.displayPrefab = adamPrefab;
        adamSurvivor.cachedName = "AdamSmithson";
        adamSurvivor.descriptionToken = "ADAM_SMITHSON_DESC";
        adamSurvivor.primaryColor = Color.red;
        
        if (portrait != null)
        {
            adamSurvivor.portraitIcon = Sprite.Create(portrait, new Rect(0, 0, portrait.width, portrait.height), new Vector2(0.5f, 0.5f));
        }

        SurvivorAPI.AddSurvivor(adamSurvivor);
    }
}
using BepInEx;
using RoR2;
using R2API;
using UnityEngine;
using System.IO;

[BepInPlugin("com.yourname.adamsmithson", "Adam Smithson Mod", "1.0.0")]
[BepInDependency("com.bepis.r2api")]
public class AdamSmithsonPlugin : BaseUnityPlugin
{
    public static GameObject adamPrefab;
    
    public void Awake()
    {
        CreateCharacter();
        RegisterCharacter();
        Logger.LogInfo("Adam Smithson Mod Loaded Successfully!");
    }

    private void CreateCharacter()
    {
        adamPrefab = PrefabAPI.InstantiateClone(Resources.Load<GameObject>("Prefabs/CharacterBodies/CommandoBody"), "AdamSmithsonBody", true);
        adamPrefab.GetComponent<CharacterBody>().baseMaxHealth = 10000f;
        adamPrefab.GetComponent<CharacterBody>().baseDamage = 500f;
        adamPrefab.GetComponent<CharacterBody>().baseMoveSpeed = 7f;

        // Passive Ability: Lurking Dread
        adamPrefab.AddComponent<LurkingDread>();
    }

    private void RegisterCharacter()
    {
        string modPath = Path.Combine(BepInEx.Paths.PluginPath, "AdamSmithson");
        Texture2D portrait = ImageLoader.LoadTexture(Path.Combine(modPath, "portrait.png"));

        SurvivorDef adamSurvivor = ScriptableObject.CreateInstance<SurvivorDef>();
        adamSurvivor.bodyPrefab = adamPrefab;
        adamSurvivor.displayPrefab = adamPrefab;
        adamSurvivor.cachedName = "AdamSmithson";
        adamSurvivor.descriptionToken = "ADAM_SMITHSON_DESC";
        adamSurvivor.primaryColor = Color.red;

        if (portrait != null)
        {
            adamSurvivor.portraitIcon = Sprite.Create(portrait, new Rect(0, 0, portrait.width, portrait.height), new Vector2(0.5f, 0.5f));
        }

        SurvivorAPI.AddSurvivor(adamSurvivor);
    }
}

// Ability: Passive Lurking Dread
public class LurkingDread : MonoBehaviour
{
    private CharacterBody body;

    void Start()
    {
        body = GetComponent<CharacterBody>();
    }

    void Update()
    {
        if (IsInDarkness())
        {
            body.moveSpeed *= 1.15f;
            body.healthComponent.health *= 1.20f;
        }
    }

    private bool IsInDarkness()
    {
        return Physics.Raycast(transform.position, Vector3.down, 5f);
    }
}

// Load PNG Files
public static class ImageLoader
{
    public static Texture2D LoadTexture(string filePath)
    {
        if (!File.Exists(filePath))
        {
            Debug.LogError($"[AdamSmithsonMod] Image not found: {filePath}");
            return null;
        }

        byte[] fileData = File.ReadAllBytes(filePath);
        Texture2D texture = new Texture2D(2, 2);
        texture.LoadImage(fileData);
        return texture;
    }
}
